﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _04_FutureValue_For
{
    public partial class frmFutureValue : Form
    {
        public frmFutureValue()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal monthlyInvesment = Convert.ToDecimal(txtMonthlyInvestment.Text);
            string yearlyInterestRate = txtYearlyInterestRate.Text;

            decimal newYearlyInterestRate = decimal.Parse(yearlyInterestRate.TrimEnd(new char[] { '%', ' ' })) / 100m;

            //MessageBox.Show(newValue.ToString());
            int years = Convert.ToInt32(txtNumYears.Text);
            int months = years * 12;
            decimal monthlyInterestRate = newYearlyInterestRate / 12 / 100;
            decimal futureValue = 0m;
            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + monthlyInvesment) * (1 + monthlyInterestRate);
            }
            txtFutureValue.Text = futureValue.ToString("C");
            txtMonthlyInvestment.Focus();
        }

        public void ToPercent (object sender, EventArgs e)
        {
            decimal yearlyInterestRate = Convert.ToDecimal(txtYearlyInterestRate.Text);
            txtYearlyInterestRate.Text = yearlyInterestRate.ToString("P");
        }
    }
}
